class TokenListrikModel {
  String nominal;
  bool isSelected;

  TokenListrikModel(this.nominal, this.isSelected);
}
